---
name: motion-director
description: "Create, replicate and refine motion graphics videos in any visual style: explainers, promos, product/UI demos, kinetic typography, or a close match of a reference video or image the user provides, including styles that are not in the preset list. Works from a style choice and a measurable style spec, through a storyboard and look test, to a reviewed MP4 with music and sound design, checked against written acceptance criteria. Use when the user wants a motion graphics video, an animated explainer, a product or SaaS interface demo, kinetic typography, wants to recreate the look of a reference, or wants to improve an existing motion piece. Always starts by showing a 12-card menu (9 styles + 3 depths: 2D / 2.5D / 3D) plus a custom/reference option and asking the user to pick."
metadata:
  version: "1.9.0-en"
  display_name: "motion_director"
---

# motion_director

## Language

Ask questions, present the storyboard and write the final report in the user's language. On-screen text and captions use the language of the brief, or the language the user asks for; check that the chosen font has every glyph that language needs. Internal working notes may stay in English.

## What "quality" means here

Quality is checkable, not a matter of taste. A result is good when:

1. it **matches the chosen style spec** (preset, saved card, custom description or reference), and
2. it **passes the craft checks** that apply to every style (section 3), and
3. it **meets the brief**: text, format, duration, sound.

More camera motion, more blur, more particles or more detail are not quality in themselves. They are style parameters. A static, flat, crisp video is correct when the spec says static, flat and crisp. Choices that sit outside the spec and the brief are reported as optional alternatives, never as defects or as "improvements".

The user's brief, chosen style, depth, format, references and permitted resources take priority over every default in this skill. Do not invent real product features, prices or confirmed preferences.

By default, prefer plain HTML/CSS/JavaScript, SVG/Canvas and your own controlled timeline when they reach the spec. Use libraries and engines (Three.js, Lottie, Remotion and others) when the spec genuinely needs them; do not install dependencies up front without benefit.

## 0. Style, depth and format first (mandatory)

Before any storyboard, code or generation for a new video, ask the user which **style** and which **depth** to use. Present all 12 cards from [style menu](references/style-menu.md) in one numbered list: styles 1–9 (Hand-drawn, Paper collage, Vector illustration, Comics and stickers, Pixel, Kinetic typography, Neon tech, Premium 3D, SaaS / UI) and depths 10–12 (2D, 2.5D, 3D). Add saved style cards and a **custom** option, where the user pastes their own description or gives a reference video, GIF or image. The user picks one style and one depth, for example "3 + 11". If the brief does not state the aspect ratio (16:9 / 9:16 / 1:1) and duration, ask for them in the same message.

Wait for the answer. If the brief already names a style, show it pre-selected and confirm it; do not skip the question. Revisions of a video already in progress keep their chosen style and do not ask again. After this, ask at most one more short question, and only about something that changes the look or the structure a lot and cannot be measured or inferred. For example: should there be a voice-over? Otherwise decide yourself and state the assumption. A simple idea is enough; no technical questionnaire.

## 1. Style spec and acceptance criteria

Turn the choice into a written **style spec** before the storyboard:

- **Preset or saved card:** expand its prompt from the menu into concrete values.
- **Reference (video, GIF, image):** measure it per [reference match](references/reference-match.md). This is the route for any style that is not in the menu.
- **Custom text description:** fill the same fields and mark every assumption.

Spec fields, each set to a value, "not used" or "free":

| Field | Examples of values |
|---|---|
| Palette | background, main and accent colours as hex; how many colours; gradients yes/no |
| Shape and line | geometric / organic / hand-made; line weight or unit size (art pixel, voxel, grid cell) as % of the frame's short side; edge: crisp, rough, die-cut |
| Surface | flat, paper texture, grain, glossy/matte material |
| Light and shading | none (flat), cel steps, soft studio, hard spot, glow |
| Typography | font class, weight, case, tracking, cap height as % of the frame's short side, how words enter and hold |
| Motion grammar | easing family; overshoot/squash amount; drawn frame rate (on 1s, 2s, 3s, 12 fps…); typical move length in frames |
| Camera grammar | static / 2D pan-scale / 2.5D parallax / 3D path; how fast; cuts vs continuous |
| Optics | motion blur yes/no, depth of field yes/no, bloom, film grain |
| Transitions | which types, their length in frames |
| Composition | margins and safe area for the target format, grid, density, where the focus sits |
| Sound | genre/tempo, SFX character, voice yes/no |

Sizes are relative to the frame's **short side**, so they survive a change of aspect ratio. When the target format differs from the reference (for example 16:9 → 9:16), keep the sizes and the grammar, and re-compose for the new frame and its safe area; do not stretch or crop the layout. Times are in **seconds** (or in frames *with* their fps), so tolerances survive a change of frame rate.

Then write the **acceptance criteria**: brief requirements, spec values and the craft checks from section 3, each with the way it will be verified (frame number, measurement, side-by-side image, loudness reading). Mark each **M** (mandatory) or **D** (desirable). Brief requirements, the spec fields that define the look and the craft checks are M; fine timing tolerances and secondary details are usually D. This list is the pass/fail standard for the review in section 5.

## 2. Direction before implementation

Develop a single through-line and a complete dynamic storyboard. For **each scene**, propose 3–5 substantially different options **inside the style spec**, and pick the strongest one with the whole piece in mind. Short options, the chosen solution and a practical storyboard are enough. For every shot, define the semantic accent, composition and layers, action, text and its motion, camera (as the spec allows), light/focus, entry, exit, sound and rhythm. Scenes develop the story causally. Details: [storyboard](references/storyboard.md).

When matching a reference, the reference sets the visual and motion grammar, and the story and content stay the user's. Copy the reference's exact shots, characters, logos, text or music only if the user asks and has the rights.

Before the full build, make a **look test**: 1–3 key frames and a short motion test at final quality. Compare them with the spec, side by side with the reference when there is one. Fix the mismatches first. This is also where the main technical risk gets tested.

## 3. Craft checks for every style

These hold whatever the style is. Their amount comes from the spec.

- **Readability:** every required word is fully inside the safe area. Default safe area: 5 % margin on each side for 16:9 and 1:1; for 9:16, 6 % at the sides, 12 % at the top and 20 % at the bottom (platform UI). Text contrast is at least 4.5:1, or 3:1 for large bold display text. Once a phrase is complete, it stays on screen at least 0.3 s per word plus 0.5 s; for captions that build word by word, count from the last word. If an exact reference match needs less contrast or shorter holds, follow the reference only when the user asked for an exact match, and list it in the report as a deliberate deviation.
- **Timing and spacing:** each action has a readable start, peak and end. Easing follows the spec, and so do anticipation, overshoot and settle (big in Comics, subtle in Vector, stepped in Pixel). There are no accidental pops, jitter, one-frame flashes, popping layers or unintended speed changes.
- **Hierarchy:** one main focus at a time; secondary motion supports it and does not compete with it.
- **Dynamics:** no fully still frame for longer than 1.5 s, except a final hold of at most 2 s. Short pauses add up, so the total still time (not counting that final hold) stays under about 20 % of the runtime. Keep text holds alive with small secondary motion (a drift, a breathing accent, an ambient element) rather than freezing the whole frame. Both limits apply unless the spec or brief asks for stillness (for example, a calm minimal style). Check it with a frame-difference scan on the export. Moves come to rest over at least 3 frames at 60 fps, unless the spec asks for hard stops or stepped motion. Elements that start together are staggered, unless the spec says otherwise.
- **Frame use and scale:** during the main action, the main subject fills at least half of the frame's long side, unless the spec asks for a small subject in negative space. For vertical social video (9:16), the headline's cap height is at least 3.5 % of the frame height, and any text is at least 2 %.
- **Brand moment:** when the brief names a product or brand, its name or logo is the main focus for at least 1 s and appears by 70 % of the runtime.
- **Continuity:** across cuts and transitions, position, scale, direction, light and identity match. Every transition has a carrier.
- **Camera:** only what the spec allows. A static camera is correct if the spec says so. Any camera path must not overshoot its keys or drift by accident.
- **Optics:** motion blur follows relative motion and depth of field follows the meaningful subject, *when the spec uses them*. Motion blur has enough sub-samples that no separate ghost copies are visible. Crisp styles stay crisp.
- **Sound:** fitting music and SFX by default, driven by the same event timeline as the picture. Each accent lands on the frame of its visual event. Silent only if the brief says so; never call a silent result "with sound".

How to execute camera, optics, typography and sound well when the spec uses them: [motion and sound](references/motion-and-sound.md).

## 4. Build

Render on a controlled timeline (frame `i` at `i / fps`) so every frame is reproducible. Default deliverable: **MP4, H.264, yuv420p, BT.709, AAC**, 60 fps output. The size follows the aspect ratio: 1920×1080 (16:9), 1080×1920 (9:16) or 1080×1080 (1:1). A drawn frame rate lower than 60 (for example 12 fps stepping) is part of the style and lives inside the 60 fps file. Explicit brief parameters override these defaults. Keep editable sources as an extra deliverable. An HTML preview does not replace the video. Details: [review and export](references/review-and-export.md).

**Draft first, master last.** Every build before the final one is a fast **draft**: half resolution (960×540, 540×960 or 540×540), 30 fps on the same time-based timeline (draft frame `k` is master frame `2k`), motion blur and other sub-sampling off, depth of field at low sample count, a fast encode, the real audio mix. Name drafts `draft_v1.mp4`, `draft_v2.mp4`… and do all review and fixing on them. Render the **master** (full size, 60 fps, full optics, `final.mp4`) once, only after every M criterion that a draft can show passes. Then run the master-only checks. If a master check fails, fix it and re-render only the affected frame range at master quality. Never deliver a draft as `final.mp4`. If the brief asks only for a quick preview, deliver the draft and label it as a draft. Exact settings: [review and export](references/review-and-export.md#draft-and-master-renders).

## 5. Mandatory review after the first build

Treat the first build as an internal draft, rendered in draft mode (section 4). Review the decoded export: the whole video at speed, every scene and seam, and the sound. Include a frame-difference scan, which shows still stretches, dead stops and one-frame pops. Check it against the acceptance criteria and write the result as a table: **criterion → PASS / FAIL / UNVERIFIED → evidence** (frame, measurement or side-by-side image). Fix the causes of FAILs, re-check what changed and the whole, and repeat until every **M** criterion passes. D failures are fixed when cheap, otherwise reported. Iterate on drafts; the table says for each row whether the evidence comes from a draft or from the master. Optics, fine text edges, one-frame pops at 60 fps, the format and the loudness are judged on the master only.

Report honestly. A check you could not perform (for example, real-time viewing or listening) is UNVERIFIED, never PASS. Do not claim that the skill or the result is effective because of the instructions or one good frame. Optional taste ideas go in a separate short list, after the table.

### Additional modules: only when the task needs them

- Matching a reference video, GIF or image, or a style not in the menu: [reference match](references/reference-match.md). Inspiration and combining several references: [video references](references/video-references.md).
- Image series, a character, alpha: [identity continuity](references/image-continuity.md).
- Ready-made 3D models, materials, hinges: [3D assets](references/models-3d.md).
- Product interface animation, cursor and states: [SaaS/UI motion](references/saas-ui-motion.md).
- Style presets, saved style cards and verified sources: [registry](references/styles-and-sources.md). The visual language comes from the user's answer to the style menu, never from your own pick.
- Measuring helper: `scripts/analyze_reference.py` (needs Python 3 and FFmpeg). `probe` gives cuts, palette and drawn frame rate of a reference; `compare` makes a side-by-side image and a palette distance.
