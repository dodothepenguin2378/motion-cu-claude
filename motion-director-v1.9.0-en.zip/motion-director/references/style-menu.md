# Style and depth menu — ask before any work

Every new video starts with this question, before the storyboard, before any code or generation. Ask it even if the brief looks complete. If the brief already names a style or a depth, show it pre-selected and ask the user to confirm it.

## How to ask

1. Present all **12 cards** of the source menu in one numbered list, in the language the user is writing in: **1–9 styles**, then **10–12 depths** (10 = 2D, 11 = 2.5D, 12 = 3D), plus **Custom** and any saved style cards. Give each card its name and a one-line summary. Do not paste the full prompts unless the user asks. The user answers with a style number and a depth number, for example "3 + 11" (Vector illustration in 2.5D).
2. Always offer a **custom** option. The user may paste their own style description, name a saved style card from [the registry](styles-and-sources.md), or give a reference video, GIF or image. A reference is measured and matched with [reference match](reference-match.md); this covers any style that is not in this menu. If the brief does not give the aspect ratio (16:9 / 9:16 / 1:1) and duration, ask for them in the same message.
3. You need both a **style** (1–9, a saved card, or custom) and a **depth** (10–12). If the user picks a style that implies a depth (Pixel → 10, Premium 3D → 12), pre-fill that depth and only confirm it. If the user picks only a depth, ask once for the style or a custom description; do not choose it yourself.
4. Wait for the answer. Do not build, storyboard or pick a style on the user's behalf. If the platform has a structured question tool with a small option limit, list the menu in text and ask for the numbers; do not drop styles to fit the tool.
5. Repeat the chosen style and depth back in one line, then continue to the storyboard. Write the chosen prompt text into the storyboard header so every scene follows it.

The chosen style and depth are part of the explicit brief. They take priority over every default, and the expanded style spec (SKILL.md section 1) is what the result is checked against. Adapt those defaults to the style instead of overriding it. For example: in 2D, the camera moves within the frame plane (pans, scale, framing shifts), not as a 3D fly-through. In Hand-drawn or Pixel, motion blur and depth of field give way to the style's own frame rate and crisp edges. In Neon tech, there is no reflective floor. Iteration, sync and export rules stay in force for every style.

## Styles

| # | Style | Prompt to use |
|---|---|---|
| 1 | **Hand-drawn** | Style: ink drawing on light paper. Lively, uneven contours, in places a doubled line and small gaps; no fills or hatching. Lines are drawn along the path of the pen; contours "boil" slightly, redrawn 8–12 times per second; motion is soft and restrained. |
| 2 | **Paper collage** | Style: paper collage. Shapes cut from coloured paper with an uneven edge and visible texture; each layer casts a soft shadow onto the one below. Move elements layer by layer, like cut-outs on a table: shifts and turns with slight stop-motion stepping; depth comes from the parallax of the layers. |
| 3 | **Vector illustration** | Style: flat vector illustration. Clean geometric shapes, a restrained palette of 4–5 colours, no textures, plenty of air, a clear composition on a grid. Motion is precise and smooth (ease-in-out), with neat transformations and shape morphing. |
| 4 | **Comics and stickers** | Style: comics and stickers. Thick black outline, bright flat colours, a white sticker die-cut around shapes, halftone dots and sound-effect lettering. Motion is short and springy: jumps, squash and stretch, a bounce with overshoot, and speed lines. |
| 5 | **Pixel** | Style: pixel art. One low-resolution pixel grid, a palette of 12–16 colours, crisp silhouettes with no smoothing. Frame-by-frame animation at 8–12 drawn frames per second; objects move only by whole pixels; pixels stay sharp when scaled. |
| 6 | **Kinetic typography** | The hero is the text: large words, contrast of sizes and weights, one key word picked out in colour. Words appear to the rhythm of the speech or music (shifts, masks, changes of scale and angle), and each word stays on screen long enough to be read. |
| 7 | **Neon tech** | Style: neon tech. Thin glowing lines in 2–3 colours on an almost black background, HUD elements, grids and data, a soft glow without blown-out highlights. Lines draw on, scan and pulse; no reflective floor and no stray glare. |
| 8 | **Premium 3D** | Style: premium stylised 3D. Simplified volumetric shapes with rounded edges, glossy and matte materials, soft studio light and contact shadows, a pastel palette. This is graphics, not photorealism: the camera glides around the object and depth of field picks out the main thing. |
| 9 | **SaaS / UI** | Style: product interface animation. Light UI cards with rounded corners and soft shadows in gentle 3D perspective, and a large, clearly visible cursor. Show the action step by step (hover → click → state change → result) with smooth transitions and readable interface text. Rules: [SaaS/UI motion](saas-ui-motion.md). |
| — | **Custom / reference** | The user's own description, a saved style card, or a reference video, GIF or image. A text description goes into the spec fields with assumptions marked. A reference is measured with [reference match](reference-match.md). |

Original names (Russian source menu), useful when the user writes in Russian: 1 Рисованный от руки, 2 Бумажный коллаж, 3 Векторная иллюстрация, 4 Комиксы и стикеры, 5 Пиксельный, 6 Кинетическая типографика, 7 Неоновый технологичный, 8 Премиальный 3D, 9 SaaS / UI. Depths: 2D, 2,5D, 3D.

## Depth

| Depth | Prompt to use |
|---|---|
| **10 · 2D** | Animate in 2D: flat shapes, clear silhouettes and motion within the plane of the frame. Keep the composition simple and readable. |
| **11 · 2.5D** | Place flat elements on several planes. Create depth with parallax, soft shadows and a small camera move. Do not fake real thickness or side faces. |
| **12 · 3D** | Animate stylised volumetric shapes in three-dimensional space. Use perspective, soft lighting and a meaningful camera move. |

## Saving a new style

When the user supplies a custom style and approves the result, offer to save it as a style card in [the registry](styles-and-sources.md). From then on, list it in this menu under the numbered styles.
