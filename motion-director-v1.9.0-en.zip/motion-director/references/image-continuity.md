# Images and a sequence of one hero

When consistent images are needed, use a source reference/editing process for one character, object or scene. For choosing a permitted route, see [conditional image sources](image-providers.md). Preserve identity, proportions, construction, style, lighting and anchor details; change exactly the specified pose, position, angle or parts of the action. For each new pose, feed the same canonical set of references, not just the latest regeneration with accumulated drift. Do not create each next frame as an independent look-alike hero with no tie to the source.

Before generation, fix the constant features, camera/shot scale, anchors, scale, light source, background/alpha and what changes in each phase. Afterwards, align anchor points, silhouette and contact; check face/anatomy, hands, object details, perspective and light direction. State the actual intervals at which each state appears in the video. The task sets the number of poses; there is no universal fixed count.

Swapping three poses is a discrete series, not a full smooth rotation. Crop, zoom, interpolation or 2.5D parallax of one image is not a new pose or a free 3D camera. A smooth transition needs sufficiently consistent intermediate states or real geometry; choose the method by task and name the result honestly. Do not pass off morphing of wrong anatomy as smoothness.

For transparency, create a real PNG with alpha. A drawn checkerboard or a solid background is not transparency. Check the alpha channel, the edge on dark and light backgrounds, color halos and premultiplied alpha. Export and scaling must not bring back a baked background or a ragged edge.

If an image is used in motion, give it a role in the action: hero, contact object, spatial layer, material or participant in a transformation. Tie the motion to the storyboard. A simple pan over a passive picture does not replace the promised action. Layers and inpainting of hidden areas must hold up to the chosen camera; do not promise a credible new angle from data that is not in the source.
