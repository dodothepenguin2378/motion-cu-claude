# Ready-made 3D models and placing them in the scene

For a personal task you may pick and download suitable ready-made free models within the current request. Prefer GLB/glTF when it fits the chosen renderer and export. Check the specific object and its terms; "free" does not mean any rights. Do not introduce a blanket download ban because of hypothetical future commercial use or source distribution, and do not forbid the user from showing devices in the video.

Use an actually available source and an ordinary permitted download. Do not circumvent access restrictions and do not present missing access as an obtained model. Do not turn the search into unauthorized registration or installing integrations. Choose from the [3D source registry](3d-sources.md); do not invent unknown services, terms or pricing.

## Before the scene

1. Check the exact model/variant, format and completeness: mesh, UV, textures, materials, rig/animations and external dependencies. Open or render the actual file, not just the page preview.
2. Normalize units and scale, axes, position, orientation, origin/pivot. Check normals, edges, thickness, topology, transparency, roughness/metalness, texture color space and renderer compatibility. Do not substitute plain WebGL material properties for WebGPU/TSL ones.
3. Check texture availability after loading, sizes, paths and alpha correctness. Make sure the model does not fall apart at the chosen shot scale. Reduce heavy meshes/textures while keeping the silhouette and needed details; check the real render rate and the export path.
4. Set up light, environment, exposure, camera, shadows and contact for the chosen material. Plastic, metal and glass must differ in surface behavior. A bright highlight and a general gradient do not fix wrong form.
5. For a laptop, check the separate lid and base and the hinge axis. Opening is a relative rotation of the lid around the hinge, not a rotation of the whole body. Check the closed and open states, the screen, the initial orientation and that no stray underside shows in the staging.

The needed hide/reveal, labels and camera serve one spatial scene. On a close pass, keep focus on the hero and the correct scale; do not cross the surface with the near plane. When replacing a model, re-check orientation, pivot, light, contact and animation.

## Short notes at the end of the result

List the sites/pages and specific files actually used: asset author/title, link, format, stated license or terms with the check date, required attribution and changes. Rights to code, model, textures, font and music may differ. If the needed scope of use is actually restricted, state it precisely and find a permitted alternative; do not turn an ordinary personal download into a legal barrier. Do not call the right to view or download a right to resell or redistribute the asset.
