# SaaS/UI motion — product interface animation

Conditional module inside `motion_director`, not a separately installable skill. Apply it to demos of a product or interface, or to the interface parts of a larger video. Here "SaaS/UI motion" is a short name for staging an interface, not a claim that the SaaS business model dictates a strict artistic style.

Transfer principles, not other people's implementations, brand palettes, project-specific tastes, mandatory durations, BPM, engines or tool installs.

## Action and result

For each episode, pick a clear task: select an element, change a setting, drag a card, rearrange a panel, start a process or show a result. Show one plausible application with consistent data and states, not an unrelated decorative card under a new title in every scene. Keep the hierarchy of cards/panels/buttons and consistent radii, shadows and line weights. In one action, highlight only a few main controls (a guideline of 1–3, not a universal quota). Do not present demo data as real features or metrics of an existing service.

The cursor drives the action: hover → the target reacts → press/grab → change → readable result. It should not fly randomly over a passive screen. Hits are determined by the arrow tip/hotspot, not the center of the sprite. Before a click, give a short readable hover; after it, a visible causal state change. The cursor stays sharp and fully visible during the press and does not cover the button label, the result or readable numbers.

Button and object states are causally linked: hover, pressed/dragging, processing, success/selected or another meaningful set. Do not show success before the process finishes. A chart, a percentage and any other indicator of the same operation share one progress value. Do not present an editorially shortened wait as the product's real speed: if needed, mark the shortening or the demo nature.

When dragging, fix the grab point and the cursor–object offset: the card lifts and follows along an arc, the drop zone highlights, and on drop the card gently shrinks and slots in. Follow/lag can convey weight and inertia but must not look like a lost grip: the main object stays controlled, lags or catches up for a reason, and neighbors react after the event. Drop, snap and residual settle end in a stable, clear layout. Do not apply the same spring to every layer.

Pick durations and amplitudes for the pace, the frame size and the reading window. A useful starting preset: cursor travel of 0.6–0.9 s along a small arc, a slight squash on click and recovery afterwards, entering and exiting off-frame. This is an example setting, not a universal norm; entering/exiting beyond the frame is compatible with full visibility at the moment of the click. Do not carry numeric presets mechanically into every scene.

Show a few functional micro-reactions: a target highlight, a state change, a neighboring card responding, a panel expanding. They support the main meaning rather than competing with it. Motivate a cut to a detail by an action; text gets reading time. Tie individual expressive cuts, reveals and move endings to real music/SFX accents per the [motion and sound module](motion-and-sound.md), not to every beat.

When handing an object between scenes, match its screen position, size and state; do not leave a double or a ghost remnant. A result emerges from the element that triggered it; cards part along soft arcs. In a morph, change the real dimensions of the shape/layout; do not stretch the entire UI together with text and radii. Preserve the interface's identity when moving from a flat view to a spatial one.

The camera helps the action: it can follow the caret, push in to a click, pull back for the result or orbit separated layers. A close-up lets the viewer read a detail; a wide shot shows the context of the app. Choose one meaningful camera gesture rather than doing all of these moves in every episode.

## One interface in 2D, 2.5D and 3D

| Mode | What must actually change |
|---|---|
| 2D + SaaS/UI | Flat panels, cards, buttons and content. Volume is not faked with random thickness; the cursor's action and the state change remain the center of meaning. |
| 2.5D + SaaS/UI | The same flat panels are separated in depth. The camera reveals relative placement, perspective, overlaps and parallax. Panels do not gain real side faces or extrusion. |
| 3D + SaaS/UI | Recognizable objects gain real geometric thickness, edges and side faces. Volume is confirmed by light, normals, shadows and a spatial orbit/fly-through, not only by scale or a drop shadow. |

When a video shows the same interface in several spatial modes (for example 2D → 2.5D → 3D), carry the same object IDs, composition anchors, colors, content and operation result across those parts. The viewer should see the spatial model of one interface change. This applies to such a sequence; it does not forbid changing the interface in another brief.

## Coordinates and reproducibility

Explicitly separate world-space UI from the screen-space overlay. If the cursor works with an object in the world, compute its screen point from the current projection of the anchor, accounting for the camera, viewport, aspect ratio and window scale. If the cursor is entirely screen-space, the target is also checked in the same screen system. Do not mix CSS pixels, video-frame coordinates and world units without conversion.

A screen-space section label keeps its position and styling while the camera moves. Tags on world-space objects may follow their projection; check margins, overlap, depth and leaving the camera's view. A volumetric panel must not accidentally cover a cursor that is staged as an overlay, or cross required text.

For reproducible video, animate the cursor, grab, states and delays on one controlled timeline. No real user input is needed for playback. Compute states from time or from a reproducible bake/replay, including scrubbing backwards; do not depend on the previous mouse event or on the number of frames already played. Full functional QA of fast repeated clicks, resize and reduced motion is needed if you are building a live app; do not turn an ordinary video demo into interactive product development.

## Check

Check at speed and at the seams: clarity of the action, grab accuracy, drop completion, sync of progress and states, consistent interface identity where required, distinguishability of the three spatial modes, projection during camera moves and scrubbing, and overlay readability. Then check the final decoded export with sound. The presence of a cursor, translateZ or an extrusion parameter in code does not prove the visual result.
