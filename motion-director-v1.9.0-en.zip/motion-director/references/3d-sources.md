# Sources of ready-made 3D models

Conditional module: read it when the brief needs ready-made models. The information below reflects documentation checked as of 2026-10-16; it does not mean every file was downloaded and tested. The terms and availability of a given release can change: check its page and the bundled license when downloading. The order below is a choice by task, not a mandatory chain of sites.

| Task and source | What to consider when choosing |
|---|---|
| Realistic objects — [Poly Haven Models](https://polyhaven.com/models) | glTF, CC0, no registration. Good for realistic items; check the texture set and the actual model. |
| Stylized kits — [Kenney Assets](https://kenney.nl/assets) | Pick a 3D kit specifically: GLB available, CC0. "Continue without donating" lets you get a free kit without a mandatory donation. |
| Characters and rigs — [Quaternius](https://quaternius.com/) | Free Standard releases often include FBX/glTF; Source may be paid. Keep the license of the exact release you chose; do not assume the whole site is CC0. See the note below. |
| Real 3D scans — [ambientCG](https://ambientcg.com/list?type=3d-model,terrain) | CC0; check the format and contents of the ZIP. Do not promise that every object is available as GLB. |
| Specific devices and other models — [Sketchfab](https://sketchfab.com/) | Look for downloadable/free, glTF/GLB and the terms of the specific model. Downloading requires an account; use access that is already available or another source — do not register on your own. |
| Free models with a format filter — [CGTrader](https://www.cgtrader.com/3d-models?free=1) | Check the glTF filter, the real zero price and the individual terms. "Free in subscription" is not a free download; waits and limits are possible. |
| Stylized characters — [KayKit Adventurers](https://kaylousberg.itch.io/kaykit-adventurers) | Free part: 5 FBX/glTF models, CC0; extras are paid. Do not attribute all the extra content to the free part. |
| Technical fallback — [Khronos glTF Sample Assets](https://github.com/KhronosGroup/glTF-Sample-Assets) | GLB/glTF for compatibility and technical scenes. The license is stated in each asset's README; do not replace it with the repository's general license. |

**Quaternius:** [QAL v1.0 of 2026-08-28](https://quaternius.com/license.html) allows personal and commercial finished projects but forbids redistributing standalone assets, packs and templates. Some older specific releases may keep CC0. Do not carry one release's license over to another. For this skill package, keep information and links rather than bundling a model into the distributed skill.

**Poly Pizza:** do not choose it as the primary automated source: its [terms](https://poly.pizza/docs/tos) restrict automated downloads. This is a local restriction on the acquisition method, not a ban on 3D in the project. Choose another suitable free source; do not circumvent access restrictions.

An ordinary permitted download for a personal video does not require abandoning the whole project over possible future commercial use. At the end of the result, briefly state the source, the asset author, the release/version and the terms actually used. If a model is unavailable, paid, or its terms do not fit the specific use, look for the next one; do not treat "free" as permission for any kind of distribution. Model preparation is described in the [3D workflow](models-3d.md).
