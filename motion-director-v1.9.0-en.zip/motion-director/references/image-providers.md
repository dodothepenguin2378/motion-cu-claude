# Images: conditional choice of source

Read only when images or reference editing are needed. Information current as of **2026-10-16**. Documentation was checked, not practical character-identity preservation. The information below does not set up integrations and does not imply account access. Use an already available, permitted tool; new registrations, MCP/API or a local backend are not enabled automatically. If one route is unavailable, choose another, keeping the staging and stating honest limitations.

## Main candidates

### Krea — ready MCP candidate

[Official guide](https://www.krea.ai/docs/developers/mcp), endpoint: `https://api.krea.ai/mcp`.
MCP via OAuth spends workspace compute units; an API token spends a **separate paid API balance**. Do not mix these payment methods.

Per [pricing](https://www.krea.ai/pricing), Free gives 100 units daily without a card. The page's guidance is about 25 Klein or 5 Krea 3 Beta images a day; this is **not a guaranteed number of reference edits**. Do not promise free Nano Banana/GPT Image. The MCP describes discovery/schema, references via URL/base64/upload, jobs and result retrieval; read the actual schema of the chosen tool before calling it.

[Krea 3](https://www.krea.ai/blog/introducing-krea-3) claims up to 6 references; character stability was not tested. A commercial license is stated for paid plans; treat Free as a personal-test route and do not promise it is suitable for a monetized final. Native alpha is not confirmed: download the result and, if needed, remove the background locally and check the edge.

### Cloudflare Workers AI — REST candidate, not a ready universal MCP

[Pricing](https://developers.cloudflare.com/workers-ai/platform/pricing/): Free 10,000 neurons/day, reset at 00:00 UTC, no paid overage on Free; the [product page](https://www.cloudflare.com/products/workers-ai/) states sign-up without a card. Neurons are compute units, **not a number of finished images**.

For [FLUX.2 Klein 4B](https://developers.cloudflare.com/workers-ai/models/flux-2-klein-4b/), per the [schema announcement](https://developers.cloudflare.com/changelog/post/2026-01-15-flux-2-klein-4b-workers-ai/), input is multipart: up to 4 binary fields `input_image_0`…`input_image_3`, each reference **smaller than 512×512**; output sizes 256…1920, result in base64. Do not substitute a different schema or model limit.

The [REST API](https://developers.cloudflare.com/workers-ai/get-started/rest-api/) needs a narrow adapter/script in a suitable client, if separately permitted. The general `https://mcp.cloudflare.com/mcp` was not verified for this flow; do not promise a turnkey MCP. Native alpha is not confirmed.

### Web interfaces as fallback

[Gemini web](https://support.google.com/gemini/answer/14286560?hl=en) describes reference editing and download; [limits vary](https://support.google.com/gemini/answer/16275805?hl=en). This is **not a free image API** — [API pricing](https://ai.google.dev/gemini-api/docs/pricing) is separate. Automation is only possible with an actually available browser tool; an ordinary chat by itself does not mean a browser is available.

[Images in ChatGPT](https://help.openai.com/en/articles/11084440-images-in-chatgpt) is a similar web fallback, including for requesting transparency. ChatGPT Free does not mean a free API, and requesting transparency does not replace checking the result's alpha.

## Additional options and the limits of "free"

| Option | What the documentation confirms and what not to promise |
|---|---|
| [Leonardo pricing](https://leonardo.ai/pricing) | 150 tokens/day, free works are public, API is separate. [Image guidance](https://intercom.help/leonardo-ai/en/articles/8497988-image-guidance) — Limited. [Transparency](https://intercom.help/leonardo-ai/en/articles/9075772-transparency) is described for suitable SD1.5/SDXL models; combining reference + alpha on Free needs actual verification. |
| [Ideogram plans](https://docs.ideogram.ai/plans-and-billing/available-plans.md) | 30 credits/week with Google/Apple/Microsoft login; free works are public. Do not promise a free API. |
| [Hugging Face Inference](https://huggingface.co/docs/inference-providers/main/pricing) and [ZeroGPU Spaces](https://huggingface.co/docs/hub/main/spaces-zerogpu) | $0.10/month in Inference; queues and quotas in Spaces. Not a reliable default production backend. |
| [Pollinations Pollen FAQ](https://raw.githubusercontent.com/pollinations/pollinations/main/enter.pollinations.ai/POLLEN_FAQ.md) | Purchased/earned Pollen. Do not treat it as unlimited or as a free daily image API. |
| [Recraft Free](https://www.recraft.ai/docs/plans-and-billing/free-plan) | Limited free plan without a commercial license; do not promise a free commercial final. |
| Replicate / fal | Trials are not recurring-free. Do not include them in the list of permanent free routes without a fresh check of the specific offer. |

## Optional local route

[ComfyUI MCP](https://docs.comfy.org/agent-tools/mcp), a small SD1.5/IPAdapter setup and [rembg](https://github.com/danielgatis/rembg) are a separate option when a suitable environment is already available or setup is explicitly permitted. Do not install automatically. Do not promise powerful image-edit models on low-VRAM GPUs (around 6 GB): the documented benchmark for the standard Klein 4B is 8.4 GB VRAM.

For each new pose, use the same canonical references, not a chain of gradually drifting regenerations. For smooth motion it is often better to animate a consistent cutout/rig than to generate each frame independently. Check the real alpha and the edge on light and dark backgrounds: a PNG by itself does not mean transparency. Full process: [image continuity](image-continuity.md).

In the result, briefly state the provider/model actually used, the available route, the date the limits were checked and the source/terms.
