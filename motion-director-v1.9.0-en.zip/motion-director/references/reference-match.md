# Reference match: replicate any look, measured

Use this when the user gives a reference (video, GIF, image or several images) and wants that look and motion. That includes styles that exist nowhere in the menu. For loose inspiration or combining several references into something new, see [video references](video-references.md).

The goal is a match that anyone can check: every claim about the reference is a number, a timecode or a frame, and every claim about the result is the same measurement taken on our output.

## 1. Get the real material

Work from the actual file, or from frames actually obtained from a URL. A title, thumbnail or description is not the reference. If only part of it is available (for example, a poster frame), say exactly what was available and do not guess the rest.

## 2. Measure

If Python 3 and FFmpeg are available, run:

```
python scripts/analyze_reference.py probe <reference> <workdir>
```

It writes `summary.json` with size, fps, duration, cut timecodes and shot lengths in frames. It also gives the dominant palette per shot (hex + share), and the drawn frame rate: the median number of changed frames per second while something moves (12 means "on 2s" at 24 fps, 8 means "on 3s", and so on). It also writes `contact.jpg` and the middle frame of every shot. **Look at the images**, then read the numbers. Grain, compression noise or a moving background can inflate the drawn frame rate, so confirm it on a dense run of consecutive frames.

Reading the probe correctly:
- **Cuts vs flashes:** segments of 3 frames or fewer are flagged as `flash`. They are flashes, glitches or strobe accents, not shots, so list them separately as a transition device. Check the cut list against the contact sheet. On dark or low-contrast footage, re-run with a lower threshold (`--scene 0.15`). On footage with heavy flashing, use a higher one.
- **Palette roles:** `overall_palette` merges the shot palettes, weighted by shot length, with flashes excluded. Assign roles from it: **background** is the largest-share colour, **main** the next large ones, **accent** a high-chroma colour with a small share. When the reference has several looks, build the palette only from the shots of the look you are matching.
- **Several looks in one reference:** list each look with its share of runtime (for example "voxel room 70 %, kinetic-type cards 20 %, photo inserts 10 %"). By default, match the dominant look. Use the secondary ones only in the roles they play in the reference (for example, title cards). Mark impossible ones, such as live-action photos in a code render, as "not used". If two looks are close in share, ask the user which to follow.
- **Depth vs reference:** if the depth the user chose contradicts the reference (for example, 2D sprites inside a 3D room), describe the reference's real spatial model in the spec and say how you reconcile the two.

Measure the rest on frames (extract consecutive frames with FFmpeg where motion matters):

- **Motion and easing:** follow one object over consecutive frames and write its position per frame. A simple colour-mask or bounding-box measurement on extracted frames is enough. Measure object motion against fixed background features, or in a shot with a static camera, so camera motion is not counted as object motion. Check drawn stepping in a region the camera does not move. Equal steps mean linear; shrinking steps, ease-out; growing steps, ease-in. A pass beyond the end point that comes back is overshoot or spring: note the percentage and the settle time in frames. Note squash/stretch amounts.
- **Timing:** how long words and holds stay on screen, and how long typical moves and transitions take (in frames). Note the beat if motion follows music.
- **Line and shape:** line weight in px relative to frame height, edge quality (crisp, rough, boiling, die-cut), corner radius, outline yes/no.
- **Surface, light, optics:** flat / textured / shaded, light direction and hardness, shadows (none, soft drop, contact), motion blur present yes/no, depth of field yes/no, grain, glow.
- **Camera:** static, 2D pans and scale, parallax layers, or a 3D path; cut rhythm.
- **Typography:** font class (grotesk, geometric sans, serif, display, mono, hand-lettered), weight, case, tracking, size as % of frame height, entry and exit motion. Name the closest available font; never claim it is the identical font unless that is verified.
- **Composition:** margins as % of the frame, grid, text placement, density.
- **Sound:** the probe measures loudness (integrated LUFS, loudness range, true peak). Measure tempo from onsets if there is a beat, then voice presence and where accents meet visual events. Genre and character are descriptions: mark them UNVERIFIED unless someone has actually listened. Delivery standards (loudness, true peak ≤ −1 dBTP) win over the reference's own levels.

If there is no script or FFmpeg, take the same measurements by viewing frames and mark each value as "estimated from frames".

## 3. Write the style spec

Fill the spec fields from SKILL.md section 1 with these values. Attach evidence to each one, for example "accent #E8452C, 15 % of shot 3 (shot_03.png)", and mark what could not be observed. The spec replaces the preset prompt for this video.

## 4. Choose a technique that can actually reach it

Pick the method by what the reference needs, for example:

- **Pixel art:** render at the low resolution and upscale with nearest neighbour.
- **Hand-drawn boil:** 2–3 drawn variants of each line, cycled at the measured drawn rate.
- **Paper:** texture, a soft per-layer shadow and stepped motion.
- **Voxel or low-poly 3D:** instanced geometry with the measured light.
- **Glow lines:** additive strokes with a measured blur radius.
- **Film look:** grain and gate weave at measured strength.

If a look cannot be reached in the available environment (live-action footage, photoreal characters, a proprietary font), say so up front and offer the closest achievable variant. Do not present an approximation as a match.

## 5. Look test with side-by-side comparison

Before the full build, render frames comparable to 1–3 reference frames: the same kind of shot, scale and content type. Then compare them:

```
python scripts/analyze_reference.py compare <reference_frame> <our_frame> <side_by_side.png>
```

Pair each of our frames with a reference frame of the same shot type: same scale, same kind of content, same look. Look at the side-by-side image. Read the palette distance: a dE under about 5 reads as the same colour, while 5–10 is close but visible. Fill a match table:

| Spec field | Reference (evidence) | Ours (evidence) | Status | Fix |
|---|---|---|---|---|

Default tolerances (use stricter ones if the user asks):

- main palette weighted dE ≤ 5;
- line weight within ±15 %;
- drawn frame rate the same **in time**: if the reference changes on every frame of its container (drawn rate = its fps), ours is smooth on every output frame; if it is stepped (for example 12 drawings per second), ours steps at the same 12 per second inside the 60 fps file;
- measured holds and move lengths within ±2 frames *of the reference's fps*, converted to seconds (±0.067 s at 30 fps);
- camera type, optics (blur / DOF yes or no) and outline/shadow presence exactly the same;
- typography the same class, weight and case.

Also check a short motion test against the reference's motion (easing shape, overshoot, timing), not only stills.

Iterate until the spec fields are in tolerance, then build. Repeat the comparison on the final decoded export, and add the table to the final report.

## 6. Rights

Match the grammar: palette, line, motion, timing, camera and composition rules. Characters, logos, footage, text, fonts and music from the reference go into the output only if the user asks and has the rights. Stand-in characters may use the same rendering technique (for example, pixel sprites in a voxel room), but they need their own silhouette, colours and features, so that no one would mistake them for the reference's characters. A free-licensed stand-in font or self-made music keeps the look without copying assets.
