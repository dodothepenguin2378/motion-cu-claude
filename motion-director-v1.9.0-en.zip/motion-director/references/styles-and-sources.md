# Style presets and verified sources

## Styles

The main entry point is the [style menu](style-menu.md): the user chooses a style and a depth before every new video. The presets below are older detail notes for some of those styles (pencil, paper, pixel, SaaS/UI in 2D / 2.5D / 3D); use them as extra guidance once the matching style is chosen. They are optional visual languages, not a mandatory script for every video. Do not pick the language yourself; do not treat a preset as the user's permanent preference, and do not treat earlier unapproved suggestions as chosen.

When the user approves a new style, add a short card: name, source/approval date, visual grammar (shapes, typography, material, light, camera/rhythm) and limits of applicability. The card describes a language, not a mandatory scene sequence. The three core mechanics remain, subject to the explicit brief.

## Six ready presets

Format and duration come from the brief; the presets do not set them.

| Preset | Visual language and action |
|---|---|
| Hand-drawn pencil sketch | Drawn stroke, pressure and unevenness of the line, construction of forms, light paper texture. Text or drawing appears along a meaningful pencil path; do not pass a plain outline of a print font off as handwriting. Deliberate drawing swaps are fine with a smooth, controlled camera. |
| Paper | Cut-out shapes, layers, edges and contact shadows, folds and the plasticity of the material. Stretch, squash, collision and local stop-motion stepping support the action rather than replacing it with random jitter. |
| Pixel | One working pixel grid, consistent scales of shapes and glyphs, controlled motion without accidental blurring of contours. Separate the rate of drawn states from the output fps; final text is readable. |
| 2D + SaaS/UI | A flat interface with cards, panels, buttons, a clear cursor and causal state changes. The viewer sees the product work through a concrete action. |
| 2.5D + SaaS/UI | The same interface: flat panels separated in depth; the camera reveals layers and parallax. Do not fake real 3D thickness or side faces. |
| 3D + SaaS/UI | The same recognizable objects get real thickness, edges and side faces, with matching light and shadows, volume and a spatial orbit/fly-through. The difference from 2.5D is visible in the output. |

When the three SaaS/UI presets are used in sequence, keep the identity of the interface, data and objects; change only the spatial representation. Interaction and projection rules are in [SaaS/UI motion](saas-ui-motion.md).

In a multi-part showcase (several styles in one video), use one fixed screen-space indicator throughout: constant position and styling, with only the current part's name changing. Do not bind it to the world camera; protect it from overlap and cropping. Tie energetic transitions to expressive accents in the actual music/SFX while keeping readability and meaning. This is labeling for that kind of showcase, not a universal requirement for other videos.

## Approved style cards

Optional. Each saved card is listed in the style menu next to the 9 styles, and is used only when the user chooses it; never as a default for other videos.

**NOVA 3D type** (saved by the skill owner, 2026-10-24; an example of a saved card. Other installs may remove it or add their own)
- Shapes and colour: black/near-black world (#0A0A0A); electric orange #FF4C00 is the only hue, reserved for the key word. Everything else is white or grey. No second accent, no gradients on objects.
- Typography: heavy editorial serif (Fraunces Black / Black Italic as the free stand-in), extruded with a small bevel; one orange italic word per statement. Uppercase mono micro-labels for HUD and indices (`01 / 04`), widely tracked, muted grey.
- Material and light: matte white type, satin orange type. A dark semi-glossy floor with a soft reflection and a faint hairline grid. Hard top spot pools with contact shadows, plus a rim light; fine dust on impacts.
- Camera and rhythm: physical, weighty actions (drops, landings, dolly on rails, crane); rack focus as content; hard sync points on the downbeat.
- Limits: suits statements, brand stings, titles and promos. It does not suit soft, playful, pastel or hand-made briefs, or UI demos that need a flat interface. Change the stand-in fonts if the brand fonts are licensed.

## Sources

Research notes: [3D sources](3d-sources.md) and [image sources](image-providers.md), current as of 2026-10-16. They are documentation checks, not practical tests of character preservation or of downloading every model.

Add only actually verified entries: the site and exact page, what is available, whether an account is needed, the terms of free use and of the specific file, format/output, the date and method of the check, and known limitations. Distinguish page text, preview, download access, the real file and verified work. Do not claim effectiveness from a single URL or the presence of a card.
