# Motion, optics, typography and sound

How to execute camera, optics, typography and sound well **when the style spec uses them**. This module never adds camera moves, blur, depth of field, volume or rich detail to a style whose spec excludes them. A static, flat or crisp spec stays static, flat or crisp. When the spec leaves camera and optics "free" and the depth is 3D, the cinematic approach below is the default. The goal is the quality of the chosen spec, not a demonstration of every tool.

## Camera and depth

Separate path, speed, orientation, target, FOV and focus. Design a long, coherent trajectory with waves of speed; do not chain identical ease-in-outs with zero velocity at every accent. At seams, check position, direction, screen speed and acceleration. In the readable phase of an active scene, a big move turns into a calm arc or drift. Following the hero is compatible with noticeable parallax of the surroundings. A meaningful editorial cut does not require continuous world coordinates between different locations.

Keyframed paths must not overshoot between keys. Unevenly spaced keys or a sudden change of motion (for example, a dolly that turns into a crane) can make a spline dip, sag or swing outside the keyed values before the next key. Use a monotone interpolation or explicit tangents there, and check the frames *between* keys, not only at the keys.

Foreground, midground and background differ in scale, relative motion, overlaps and perspective. Protect silhouettes and text from accidental overlap. Bind a label next to a moving 3D object to the projection of its anchor; keep frame margins, with no jitter or lag.

## Optics and material

- Motion blur reflects relative screen motion during the exposure. With a tracked, sharp hero, the background may smear. Sub-frame sampling or a suitable renderer are means, not proof of the effect. Blur weakens as motion decelerates.
- DOF isolates the chosen depth. When approaching, focus follows the meaningful detail without accidental defocus. Near and far layers may go soft; text and hero stay recognizable. In flat UI, do not create artificial unreadability just to tick a box.
- Radial/zoom blur is a separate stylized accent, suited to depth or fast cards. Do not pass it off as depth of field or temporal blur. Do not apply maximum blur to the whole video.
- Light follows reading order: the element the viewer must read first is lit at least as well as everything around it. A key word sitting outside the light pool reads as a mistake, not as mood.
- Form reads through geometry, light, normals, thickness, contact shadow and overlaps. Highlights, grain and particles do not fix wrong construction. Texture and shadow must follow the object and the light.

## Typography and rhythm

Choose an expressive, available typeface or a matched pair; check the specific glyphs the text's language needs (accents, diacritics), weights, line breaks and the license of the font file. If external fonts are forbidden, use permitted system fonts or custom geometry. First design the readable final layout, then the action of letters and words: assembly, width change, masks, spatial relationships, interaction with the object. The effect must have a semantic role.

During its whole reading window, the required text stays fully inside the frame and its safe margins, not just in one good frame. Measure the actual set width against the visible width at the subject's distance and field of view. A camera push-in late in the window is the usual cause of cut-off letters.

Combine anticipation, action, contact, reaction and settle with different masses and curves. One main accent allows coordinated secondary layers. If everything competes for attention, vary phase, scale, depth and contrast. Do not rescue the pace by removing required elements or speeding up until it becomes unreadable. Avoid repeated flashes as a substitute for energy.

## Music and sound design

Unless the user specified silent mode, music and SFX are part of the staging from the start. Choose how to obtain them according to the permitted means and the task: what matters is the musical character and the result, not a specific service or synth. Music needs a fitting motif/groove, development, contrast and resolution; a set of whooshes and hits does not replace a composition. Tie SFX to motion, contact, material and transitions rather than adding them at random.

Drive sound and picture from the same events. After a speed ramp, recompute the actual accent moment; do not unintentionally change the overall musical tempo or pitch. Listen to the full mix and the necessary layers; check balance, clipping, clicks, sync and tail. Technical metrics do not prove musical quality. If audio was not created or was not listened to, state those statuses distinctly.

### Editing to expressive accents

Account for musical points while planning sound and animation: a highlighted note, a hit, a phrase or harmony change, a pause or the return of the rhythm can support a cut, a scene reveal, an angle change, a contact or the end of a move. This is a periodic, meaningful device, not a requirement to cut on every beat. A piano note is one possible example of an accent, not a mandatory instrument or genre.

After choosing or creating the **actual audio track**, mark the timecodes of noticeable accents and the corresponding visual events. For the chosen points, record the perceived peak/onset of the accent, the target visual action and the nearest suitable frame: `frame / fps`. Account for the real audio start/offset and editorial shifts. Matching BPM, a computed grid or the start of a sound-effect file is not enough: the musical peak, the attack and the visual climax may sit elsewhere. Check them by ear and in motion to frame accuracy, not from a waveform alone.

An accent needs its visual event on the same frame, not merely during the same phrase. If an action is eased so that it visually completes before its sound (an alignment, a lock, a landing), the sound has no picture. Keep a visible remainder until the accent, then resolve it quickly on the accent frame.

If the alignment does not work, gently adjust the shot length, trajectory, reveal/landing timing or the arrangement within the brief. Do not create unnatural speed or damage the pace or intelligibility of speech for the sake of the grid. Significant semantic events, reading text, voice and an explicit no-music brief matter more than mechanically hitting the beat; in silent mode, musical sync does not apply.

Coordinate SFX with the musical gesture: a sound can support, complement or leave room for the accent. Do not layer the same whoosh on every transition and do not double every musical hit with an effect. After replacing or trimming the track, or after a speed ramp, update the accent map. Check the chosen sync points and the final mix together with the video; do not claim perfect sync without that check.

Small sync sounds (ticks, clicks, blips, key presses) are easily masked by pads, bass and reverb tails. Check that each one stands out from the bed around it, both broadband and in its own frequency band. A click can be clearly present above 2 kHz and still invisible in a broadband level. If it is masked in its own band too, raise it or carve room for it.
