# Dynamic storyboard

Needed before implementing the full video. It turns a simple idea into executable staging and keeps the three core mechanics.

1. Extract from the brief the goal, the audience, the key message, required text, format, duration, sound, permitted resources and output files. Do not invent unknown real facts; make reversible creative decisions yourself.
2. Formulate a single thread: what acts, what changes, what idea the result proves. It can be a change of material, a transfer of motion, a causal chain, the unfolding of a space or another original approach. Do not copy a previous video's sequence under a new title. When matching a reference, its style and motion grammar are the spec, but the story and content stay the user's.
3. For each scene, give 3–5 short options inside the chosen style spec that differ in action, composition/space, metaphor or transition. Changing only the color and font is not a new option. Choose the strongest by four tests: it carries the key message, it fits the style spec, it links causally to the neighbouring scenes, and it can be built well in the available toolchain. Show the choice with a one-line reason; long internal deliberation is not needed.
4. Fill in the storyboard for all scenes and seams, then check perception time and risks. This is a working plan, not a mandatory queue of user approvals. If intermediate approval is explicitly requested, respect that boundary.

## Shot card

| Field | What to record |
|---|---|
| Time and meaning | Interval, main accent, role in the overall story |
| States and action | What was there, what triggers the change, what the hero does, reaction, result |
| Space | Composition, foreground/midground/background, light, material |
| Text | Exact phrase, action of letters/words, reading window |
| Camera and optics | Path, target, rotation/speed, shot scale, focus and blur |
| Links | Entry from the previous shot, transition carrier, exit into the next |
| Sound | Musical beat, SFX and synchronized event, or explicit silent |
| Check | Main risk, actual verification method, acceptable technical fallback |

Design a transition together with both scenes. For a match cut, match the projected silhouette, scale, orientation and direction of motion. For a mask transition, the next scene must actually appear inside the mask; a random overlay after a finished cut does not prove such a transition. In a single location, keep its poses, perspective, light and speeds; tie the reveal of an object to real occlusion or action.

Before the full build, test one representative risk at real quality and in motion, with sound if present. Choose the trial length by perception and the brief; do not squeeze all events into a mandatory 5–7 seconds. A trial replaces neither the whole storyboard nor the iteration after the full build.
