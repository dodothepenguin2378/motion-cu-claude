# Video: actual analysis and combining references

Two modes. **Match** means the user wants that look and motion: follow [reference match](reference-match.md), which measures the reference and checks the result side by side. **Inspiration** means taking principles and building your own solution: follow this file. If it is unclear which one the user wants, ask.

If a file is provided, work with its real frames and available audio. If a URL is given, first actually open the page and get the available material. Do not describe editing, motion, frames or music from a title or link. A page may give only text or a poster: state the extent of access explicitly. If the video is unavailable, name the unavailable material; independent staging can continue without attributing observations from this reference to it.

Build a map of scenes and transitions with timecodes: boundaries, durations/shot scales, composition and layers, hero action, typography, camera path and speed, material/light, transition carrier, sound and rhythm. For important seams, extract a dense frame sequence before, inside and after, and watch the motion at speed. Do not determine exact speed, easing or sound quality from a single still. Do not present three chosen frames as a frame-by-frame analysis of the whole video.

Separate observation from transfer: **seen/heard in a specific interval → useful principle → own solution for the current story**. Keep the source and access status. Analyzing someone else's technique does not give the right to automatically include their video, model, font or music in the output.

## When three references need combining

Use all three meaningfully. Record which characteristic you take from each: for example, spatial composition from the first, typography from the second, camera/rhythm from the third. This is an example distribution, not a mandatory assignment. Note compatible and conflicting properties and create one shared system, not three independent fragments.

Adapt the palette, logo, materials, hero and environment on request; they do not have to copy the sources. Keep one causal thread and a consistent scale of motion. Briefly show the map "reference → characteristic → application", then build your own storyboard. Mixing references is subordinate to the three core mechanics.
