#!/usr/bin/env python3
"""Measure a reference so a style can be matched with numbers, not impressions.

Needs only Python 3 and FFmpeg/ffprobe on PATH (no pip packages).

  probe   <video|gif|image> <outdir> [--scene 0.3]
      -> summary.json: size, fps, duration, cut timecodes, shots (<=3 frames flagged 'flash'),
         drawn frame rate (unique frames per second while moving), dominant palette per shot,
         overall palette (weighted by shot length, flashes excluded), audio loudness
      -> contact.jpg, shot_XX.png (middle frame of each shot)

  compare <reference.png> <ours.png> <out.png>
      -> side-by-side image at equal height, and both palettes with the CIE76 colour
         distance from each reference colour to the closest colour in ours (dE < ~5 reads as the same)
"""
import json, math, os, re, subprocess, sys
from statistics import median

def run(args, binary=False):
    p = subprocess.run(args, capture_output=True)
    return p.stdout if binary else p.stdout.decode('utf-8', 'replace') + p.stderr.decode('utf-8', 'replace')

def probe_info(path):
    out = run(['ffprobe', '-v', 'error', '-select_streams', 'v:0', '-show_entries',
               'stream=width,height,avg_frame_rate,r_frame_rate,nb_frames:format=duration',
               '-of', 'json', path])
    j = json.loads(out[out.index('{'):])
    s = j['streams'][0]
    def rate(r):
        n, d = (r or '0/1').split('/')
        return float(n) / float(d) if float(d) else 0.0
    fps = rate(s.get('avg_frame_rate')) or rate(s.get('r_frame_rate'))
    dur = float(j.get('format', {}).get('duration') or 0)
    return {'width': s['width'], 'height': s['height'], 'fps': round(fps, 3), 'duration': round(dur, 3)}

def is_still(info, path):
    return info['duration'] == 0 or os.path.splitext(path)[1].lower() in ('.png', '.jpg', '.jpeg', '.webp', '.bmp')

def frame_rgb(path, t=None, w=96, h=54):
    args = ['ffmpeg', '-v', 'error']
    if t is not None: args += ['-ss', f'{t:.3f}']
    args += ['-i', path, '-frames:v', '1', '-vf', f'scale={w}:{h}:flags=area', '-f', 'rawvideo', '-pix_fmt', 'rgb24', '-']
    data = run(args, binary=True)
    return [tuple(data[i:i + 3]) for i in range(0, len(data) - 2, 3)]

def palette(pixels, k=8):
    """Bucket quantisation (5 bits/channel), then merge near buckets; returns [(hex, share)]."""
    buckets = {}
    for r, g, b in pixels:
        key = (r >> 3, g >> 3, b >> 3)
        s = buckets.setdefault(key, [0, 0, 0, 0]); s[0] += r; s[1] += g; s[2] += b; s[3] += 1
    cols = sorted(((v[0] / v[3], v[1] / v[3], v[2] / v[3], v[3]) for v in buckets.values()), key=lambda c: -c[3])
    merged = []
    for c in cols:
        for m in merged:
            if delta_e(c[:3], m[:3]) < 10:
                n = m[3] + c[3]
                m[0] = (m[0] * m[3] + c[0] * c[3]) / n; m[1] = (m[1] * m[3] + c[1] * c[3]) / n; m[2] = (m[2] * m[3] + c[2] * c[3]) / n; m[3] = n
                break
        else:
            merged.append(list(c))
    merged.sort(key=lambda c: -c[3])
    total = sum(c[3] for c in merged) or 1
    return [('#%02X%02X%02X' % (round(c[0]), round(c[1]), round(c[2])), round(c[3] / total, 3)) for c in merged[:k]]

def to_lab(rgb):
    def lin(c):
        c /= 255
        return c / 12.92 if c <= 0.04045 else ((c + 0.055) / 1.055) ** 2.4
    r, g, b = (lin(float(x)) for x in rgb)
    x = (0.4124 * r + 0.3576 * g + 0.1805 * b) / 0.95047
    y = 0.2126 * r + 0.7152 * g + 0.0722 * b
    z = (0.0193 * r + 0.1192 * g + 0.9505 * b) / 1.08883
    f = lambda t: t ** (1 / 3) if t > 0.008856 else 7.787 * t + 16 / 116
    return 116 * f(y) - 16, 500 * (f(x) - f(y)), 200 * (f(y) - f(z))

def delta_e(a, b):
    la, lb = to_lab(a), to_lab(b)
    return math.sqrt(sum((p - q) ** 2 for p, q in zip(la, lb)))

def hex_rgb(h):
    return tuple(int(h[i:i + 2], 16) for i in (1, 3, 5))

def overall_palette(shots, k=10):
    pool = []
    for s in shots:
        if s['kind'] == 'flash': continue
        for h, share in s['palette']:
            pool.append((hex_rgb(h), share * s['length_s']))
    merged = []
    for rgb, w in sorted(pool, key=lambda p: -p[1]):
        for m in merged:
            if delta_e(rgb, m[0]) < 10:
                n = m[1] + w
                m[0] = tuple((m[0][i] * m[1] + rgb[i] * w) / n for i in range(3)); m[1] = n
                break
        else:
            merged.append([rgb, w])
    merged.sort(key=lambda m: -m[1])
    total = sum(m[1] for m in merged) or 1
    return [('#%02X%02X%02X' % tuple(round(x) for x in m[0]), round(m[1] / total, 3)) for m in merged[:k]]

def loudness(path):
    out = run(['ffmpeg', '-v', 'info', '-nostats', '-i', path, '-map', '0:a:0?', '-af', 'ebur128=peak=true', '-f', 'null', '-'])
    summary = out[out.rfind('Summary:'):] if 'Summary:' in out else ''
    g = lambda pat: (lambda m: float(m.group(1)) if m else None)(re.search(pat, summary))
    i, lra, tp = g(r'I:\s+(-?[0-9.]+) LUFS'), g(r'LRA:\s+([0-9.]+) LU'), g(r'Peak:\s+(-?[0-9.]+) dBFS')
    return {'integrated_lufs': i, 'lra_lu': lra, 'true_peak_dbtp': tp} if i is not None else {'present': False}

def cuts(path, thr):
    out = run(['ffmpeg', '-v', 'info', '-i', path, '-vf', f"select='gt(scene,{thr})',showinfo", '-f', 'null', '-'])
    return [round(float(m), 3) for m in re.findall(r'pts_time:([0-9.]+)', out)]

def drawn_rate(path, duration):
    """Median number of *changed* frames per second, over seconds where something moves."""
    out = run(['ffmpeg', '-v', 'info', '-i', path, '-vf', 'mpdecimate=hi=64*6:lo=64*3:frac=0.2,showinfo', '-f', 'null', '-'])
    kept = [float(m) for m in re.findall(r'pts_time:([0-9.]+)', out)]
    per_sec = {}
    for t in kept: per_sec[int(t)] = per_sec.get(int(t), 0) + 1
    moving = [n for n in per_sec.values() if n > 1]
    return {'unique_frames_total': len(kept), 'median_unique_fps_while_moving': median(moving) if moving else 0,
            'per_second': [per_sec.get(s, 0) for s in range(int(duration) + 1)]}

def cmd_probe(path, outdir, thr):
    os.makedirs(outdir, exist_ok=True)
    info = probe_info(path)
    res = {'file': os.path.abspath(path), **info}
    if is_still(info, path):
        res['still'] = True
        res['palette'] = palette(frame_rgb(path, None))
        run(['ffmpeg', '-v', 'error', '-y', '-i', path, os.path.join(outdir, 'shot_01.png')])
    else:
        dur = info['duration']
        c = [t for t in cuts(path, thr) if 0.05 < t < dur - 0.05]
        bounds = [0.0] + c + [dur]
        shots = []
        for i in range(len(bounds) - 1):
            a, b = bounds[i], bounds[i + 1]
            mid = (a + b) / 2
            name = f'shot_{i + 1:02d}.png'
            run(['ffmpeg', '-v', 'error', '-y', '-ss', f'{mid:.3f}', '-i', path, '-frames:v', '1', os.path.join(outdir, name)])
            nfr = round((b - a) * info['fps'])
            shots.append({'shot': i + 1, 'kind': 'flash' if nfr <= 3 else 'shot', 'start': round(a, 3), 'end': round(b, 3),
                          'length_s': round(b - a, 3), 'length_frames': nfr, 'frame': name, 'palette': palette(frame_rgb(path, mid))})
        res['cuts'] = c
        res['shots'] = shots
        res['flash_count'] = sum(1 for s in shots if s['kind'] == 'flash')
        res['overall_palette'] = overall_palette(shots)
        res['audio'] = loudness(path)
        res['drawn_rate'] = drawn_rate(path, dur)
        n = 30
        step = max(dur / n, 1 / max(info['fps'], 1))
        run(['ffmpeg', '-v', 'error', '-y', '-i', path, '-vf',
             f"fps=1/{step:.4f},scale=320:-2,tile=6x5:color=0x202020", '-frames:v', '1', os.path.join(outdir, 'contact.jpg')])
        res['contact_sheet'] = 'contact.jpg (one frame every %.2f s, read left to right)' % step
    with open(os.path.join(outdir, 'summary.json'), 'w', encoding='utf-8') as f:
        json.dump(res, f, indent=2)
    print(json.dumps(res, indent=2))

def cmd_compare(ref, ours, out):
    run(['ffmpeg', '-v', 'error', '-y', '-i', ref, '-i', ours, '-filter_complex',
         '[0:v]scale=-2:720[a];[1:v]scale=-2:720[b];[a][b]hstack=inputs=2', '-frames:v', '1', out])
    pr, po = palette(frame_rgb(ref)), palette(frame_rgb(ours))
    rows = []
    for h, share in pr:
        best = min(po, key=lambda c: delta_e(hex_rgb(h), hex_rgb(c[0])))
        rows.append({'reference': h, 'share': share, 'closest_ours': best[0], 'dE': round(delta_e(hex_rgb(h), hex_rgb(best[0])), 1)})
    res = {'side_by_side': os.path.abspath(out), 'reference_palette': pr, 'our_palette': po, 'match': rows,
           'weighted_dE': round(sum(r['dE'] * r['share'] for r in rows) / (sum(r['share'] for r in rows) or 1), 1)}
    print(json.dumps(res, indent=2))

if __name__ == '__main__':
    a = sys.argv[1:]
    if len(a) >= 3 and a[0] == 'probe':
        thr = float(a[a.index('--scene') + 1]) if '--scene' in a else 0.3
        cmd_probe(a[1], a[2], thr)
    elif len(a) == 4 and a[0] == 'compare':
        cmd_compare(a[1], a[2], a[3])
    else:
        print(__doc__); sys.exit(1)
