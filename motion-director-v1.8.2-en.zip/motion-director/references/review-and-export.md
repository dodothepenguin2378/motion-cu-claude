# Iteration, review and export

This is a working check for mechanic 3, not a quality certificate based on the presence of code.

## After the first build

The first result is an internal unfinished draft. Do a full viewing at normal speed, then a targeted review of each scene and seam. If there is sound, listen to the full mix and the necessary separate layers. Record significant notes as: **interval → observation → cause → specific fix → re-check**. Do not simulate rework for the sake of the iteration count; if no defects were found, record what exactly was checked.

The standard is the acceptance criteria written in SKILL.md section 1 (brief + style spec + craft checks). Report each one as PASS / FAIL / UNVERIFIED with evidence: a frame number, a measurement, a side-by-side image or a loudness reading. When there is a reference, repeat the side-by-side comparison from [reference match](reference-match.md) on the decoded export. Do not mark a spec-compliant choice as a defect because another style would do it differently. For example, a static camera in a flat spec is correct.

Check, as far as the spec uses each item:

- does the idea and the causal thread read, is the hero recognizable, is there development instead of a dull hold;
- does the result match the style spec field by field (palette, line, surface, light, motion grammar, drawn frame rate, camera, optics, typography, composition);
- do camera, shot scale, perspective and layers direct attention; are speeds and seams smooth;
- does the typography perform an action, can the required words be read without a pause;
- are form, light, shadows, material, identity and contact preserved; no artifacts, accidental crops or layer conflicts;
- where the spec uses blur and focus, do they match motion and depth without hiding what is needed; where it excludes them, is the image crisp;
- do music and SFX support style, rhythm and events; no desync, clicks or abrupt cutoff;
- are the format, duration, fps, silent/offline and other explicit requirements met.

Fix significant causes, re-review the changed places together with the neighboring phases, and then the whole video again. After simplifying, compare against the brief: "cleaner" is not acceptable if required characters, text, environment or actions disappeared. Finish when everything mandatory is done and verified, significant defects are fixed, and what remains are taste alternatives outside the necessary rework.

## Implementation and the default MP4

When the task can be solved with quality using plain HTML/CSS/JavaScript, SVG/Canvas and your own controlled timeline, prefer this simple path. Do not require Remotion, Hyperframes or another framework up front, and do not install dependencies by template. This is a preference, not a ban: Three.js, Remotion, Lottie, audio libraries and other suitable tools are acceptable when genuinely needed. Choose by result quality, required capabilities, the available environment and the cost of complexity; do not promise that vanilla is always better.

The Web Audio API is a built-in browser API, not a synonym for the audio.js library. No particular music generator or synth is fixed: use a suitable permitted method, and sound libraries when they are actually needed. Do not rebuild an existing project or a stack explicitly chosen by the user for the sake of this preference.

The standard deliverable is a finished MP4 with video at **1920×1080, a steady 60 fps, H.264 and compatible yuv420p**, with **AAC** audio unless the user requested silent. Keep HTML/JS and other editable sources as an extra deliverable. Do 4K on request; an explicit size, fps, duration, codec or no-sound requirement from the brief takes priority. Do not call a file 4K/60 fps or a finished MP4 if the actual file differs.

A reliable export path without a mandatory framework:

1. Fix controlled time and a frame grid. Reproducibly render **all** frames at time `i / fps`, including complex phases and transitions; check that the sequence is complete and in order. If another engine is used, ensure the same reproducibility rather than recording random realtime playback with dropped frames.
2. Prepare and mix music, SFX and speech (when present) into a real exportable track. Account for the start, offsets, accents and ending on the shared timeline. A Web Audio real-time preview alone does not guarantee sound in the MP4: get a usable audio file/buffer through an available offline render, a recording or an equivalent reliable method, and check its actual contents.
3. Assemble the frames and the full audio mix with FFmpeg into an MP4, or use an equivalent reliable pipeline. Keep the specified frame rate and running time. When muxing, explicitly handle the needed video and audio streams: do not lose speech, music or SFX, and do not replace the full mix with a single effect. In silent mode, do not add sound on your own. Convert RGB frames with an explicit BT.709 matrix and tag primaries, transfer and matrix in the file. In FFmpeg, frame properties can override encoder flags, so set them in the filter chain as well, for example with `setparams`. Untagged or BT.601-converted video shifts saturated colours (brand hues especially) between players.
4. Align the start and the final tails with the brief before muxing. Do not cut the last scene, speech or the end of the music to mechanically match durations, and do not lengthen the video with a random audio tail. Do not apply `-shortest` blindly if the shorter stream would cut the intended ending.
5. Check the **finished decoded MP4**: actual codec/pixel format, resolution, steady fps and timestamps, frame count and exact duration, AAC and the presence of the needed audio, AV sync, start, end and scene boundaries. Watch and listen to the final mix together with the video; the source preview does not prove that the audio export succeeded.

If the environment really does not allow rendering, encoding/FFmpeg or an equivalent, or delivering the file, report the specific blocker, the completed parts and the actual format. Save and hand over the sources and the available reproduction/export instructions; do not pass HTML off as a finished video. This is an exception for confirmed unavailability, not a normal shortcut instead of the mandatory MP4. Do not install an unavailable framework automatically to get around the limitation.

## Check the delivered result

After encoding, open and decode the final export and check its motion and sound, not just the HTML or the source PNG/WAV. Check the start and end, adjacent frames before and after each scene boundary, readable holds and the fastest phases. A contact sheet helps judge compositions, a dense frame sequence a specific seam, full playback the rhythm and smoothness, and listening the sound. These kinds of evidence are not interchangeable.

If music sync was used, compare the chosen transitions/actions with the timecodes of the perceived accents of the **real track** and with the frames of the decoded export, including the audio offset after muxing. Watch and listen to them at speed, then check the full mix with the video: no shift, no obtrusive SFX repetition, no loss of meaning, reading or speech for the sake of the beat. Numerical matching of marks is not proof of perfect sync; if watching or listening is not available, this item stays unverified.

At exactly 20 s and 60 fps, expect 1200 frames on the grid 0..1199/60; the endpoint renderAt(20) is not an extra video frame. Twenty seconds here is an example of counting, not a fixed duration for all videos. The default 60 fps changes with an explicit brief. For web and social delivery without a stated loudness target, aim for about −14 LUFS integrated with true peak at or below −1 dBTP, measured on the encoded file (AAC can raise peaks). Reach it through the mix, for example by taming the few loudest hits. Do not use a fast limiter that squashes low-frequency booms, because it distorts them. A brief or platform spec overrides this target. Distinguish the presence of an audio stream from sound quality: a silent stream does not get a PASS as an audio result, and the presence of AAC alone does not confirm audible music/speech or their balance.

For a controlled timeline, re-render a frame after a cold seek, after scrubbing backwards and after jumping from another place. Analytical state, a bake or a reproducible replay is needed for simulations and accumulative effects; one random seed is not enough. Compare the source and the final file by hashes if a version needs to be preserved.

## Honest statuses

Distinguish: **implemented**, **verified by running**, **visible in frames**, **verified in motion**, **listened to**. Anything unverified does not get a PASS from parameters or a general impression. If a tool is unavailable, name the specific check that was not performed and the reason; show the available artifact with the corresponding label, without passing it off as having passed artistic acceptance. Do not invent viewing, running or the skill's effectiveness.

If the required quality truly cannot be achieved under the available conditions, report the exact blocker and the completed parts. Do not hide it after declaring the work ready. If the outcome of an external action is uncertain, find out the outcome first; do not duplicate the write. Do not ask for new permission for ordinary reversible work that is already permitted.

Do not use repeated strobing as a substitute for energy. Check risky brightness changes in the output; reduced motion and the absence of errors do not prove formal flash safety. Do not claim compliance with a standard without the corresponding analysis.
